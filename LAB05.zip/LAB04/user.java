packagecom.example.lab04;
public class User{
    private Long id;
    private String name;
    private String email;
    public Long getId(){
        return id;
    }
    public void setId(Long id){
        this.id=id;
    }public String getName(){
        return name;
    }
    publicvoidsetName(String name){
        this.name=name;
    }
    public String getEmail(){
        return email;
    }
    public void set Email(String email){
        this.email=email;
    }
    @Override
    public String to String(){
        return"User[id="+id+",name="+name+",email="+email+",
    toString()="+super.toString()+"]";
}
}