@GetMapping(path="/add")//
public @ResponseBody String addUser(@Request Param String name, @Request Param String email){
    User n = newUser();
    n.setName(name);
    n.setEmail(email);
    return n.toString();
    @NotNull
    @Size(min=3,max=30)
    private String name;
    @Email
    private Stringe mail;
}