package com.example.lab04;
importorg.springframework.stereotype.Controller;
importorg.springframework.web.bind.annotation.RequestMapping;
importorg.springframework.web.bind.annotation.RequestParam;
importorg.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(path="/lab4")
public class LabController{

    
}